/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenação;

/**
 *
 * @author UCL
 */
public class OrdenaInserção { 
    
    private int[] Vetor;
    
    
    public void OrdenarInserc(int [] vet){
             
         //Ordenando o vetor
           for (int i = 0; i <vet.length; i++) 
                {
                        int chave = vet[i];
                        for (int j = i - 1; j >= 0 && vet[j] > chave; j--)
                        {
                                vet[j + 1] = vet[j];
                                vet[j] = chave;
                        }                       
                } 
           
           
           //Imprimindo o vetor ordenando 
           
         for (int i = 0;i<vet.length; i++) {
            System.out.println(" " + vet[i]);
        }
        
        
    }
    
    
    
}
