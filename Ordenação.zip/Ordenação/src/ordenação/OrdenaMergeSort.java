/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenação;

/**
 *
 * @author marcio.silva
 */
public class OrdenaMergeSort { 
    private int[] Vetor;
    private int[] Vetor2;
    
    
    
    public OrdenaMergeSort(int[] Vetor,int[] Vetor2){
        
        this.Vetor=Vetor;
        this.Vetor2=Vetor2;
    }
    
    
    public void OrdenarMerge(int [] vet, int []vet2, int inicio,int fim){
       
        
        if(inicio<fim){
            
            int meio=inicio+fim/2;
            OrdenarMerge(this.Vetor, this.Vetor2, inicio, meio);
            OrdenarMerge(this.Vetor, this.Vetor2, meio+1, fim);
            Intercalar(this.Vetor, this.Vetor2, inicio, meio, fim);
        } 
        
        
        
    }

    public void Intercalar(int[] Vetor, int[] Vetor2, int inicio, int meio, int fim) { 
        
        for(int i=inicio; i<=fim; i++){
            Vetor2[i]=Vetor[i];
            
        } 
        
        
        int i=inicio;
        int j=meio+1;
        
        for(int k=inicio; k<=fim; k++){
            
            if(i>meio){
                Vetor[k]=Vetor2[j++];
            }
            else if(j>fim){
                Vetor[k]=Vetor[i++];
            } 
            
            else if(Vetor2[i]<Vetor2[j]){
                Vetor[k]=Vetor2[i++];
            } 
            
            else{
                Vetor[k]=Vetor[j++];
                
            }
        }
        
       
    }
    
    
    
}
