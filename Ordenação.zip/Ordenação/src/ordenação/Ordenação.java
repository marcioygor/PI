/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenação;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

/**
 *
 * @author UCL
 */
public class Ordenação {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        
        //declarando as variaveis
        
        int vetor[]=new int[1002];
        int vetor2[]=new int[vetor.length];
        int numero=0;
        int j=0;
        
        
        //lendo o arquivo de texto e jogando para dentro do vetor
        
        try{
         
            BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\Marcio Ygor\\Desktop\\Numeros.txt"));
         
         while(br.ready()){
            String linha = br.readLine();
            //System.out.println(linha);
          
                numero=Integer.parseInt(linha);
                vetor[j]=numero;
                j++;
            }
         
         
         br.close();
      
        }catch(IOException ioe){
        
          ioe.printStackTrace();
      } 
        
        //ordenando e imprimindo o vetor ordenado com o método insertion
        
        OrdenaInserção ordenain=new OrdenaInserção();
        ordenain.OrdenarInserc(vetor); 
        
        
        
         
        
   }
}

