/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ordenação;

/**
 *
 * @author marcio.silva
 */
public class OrdenaçãoBolha { 
    
     private int[] Vetor;
    
    
    
     public void OrdenarBolha(int [] vet){
         
         int aux=0;
         
         //ordenando o vetor
         for (int i = 0; i < vet.length; i++) {
           for (int j = 0; j < vet.length-1; j++) {
         
             if(vet[j]>vet[j+1]){
                 
                 aux=vet[j];
                 vet[j]=vet[j+1];
                 vet[j+1]=aux;
                 
             } 
             
           } 
           
         }
                         
             //imprimindo o vetor
             
              for (int k = 0;k<vet.length; k++) {
            System.out.println(" " + vet[k]);
        }
           
         
     }
     
     
    
} 

    
     



     
