﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using ClasseP;
using BancoD;
using b;

namespace $safeprojectname$
{
    public partial class AlterarSenha : Form
    {
        public AlterarSenha()
        {

            //posicionando o form no centro da tela 
            this.StartPosition = FormStartPosition.CenterScreen;


            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            UsuarioControl novo = new UsuarioControl();
            novo.AlterarSenha(email.Text, novasenha.Text, palavras.Text);
               

        }

              

        private void AlterarSenha_Load(object sender, EventArgs e)
        {

        }

        private void novasenha_TextChanged(object sender, EventArgs e)
        {
            novasenha.PasswordChar = '*';
        }

        private void palavras_TextChanged(object sender, EventArgs e)
        {
            palavras.PasswordChar = '*';
        }
    }
}
