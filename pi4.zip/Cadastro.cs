﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Odbc;
using ClasseP;
using BancoD;
using b;

namespace $safeprojectname$
{
    public partial class Cadastro : Form
    {
        public Cadastro()
        {

            //posicionando o form no centro da tela 
            this.StartPosition = FormStartPosition.CenterScreen;

            InitializeComponent();
            Senha.PasswordChar = '*';
        }

       

        

        private void button1_Click(object sender, EventArgs e)
        {

             bool verifica = false;

            //verificando se um nickname já existe
            BdControl novo = new BdControl();
            verifica=novo.VerificaNick(Email.Text);

              if (verifica == false)
            {
                //chamando o Método cadastrar da classe usuario
                UsuarioControl user = new UsuarioControl();
                user.Cadastrar(Nome.Text, Email.Text, Senha.Text, Pseguranca.Text);



            }

            //limpando os campos
            Nome.Text = "";
            Email.Text = "";
            Senha.Text = "";
            Pseguranca.Text = "";



        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Cadastro_Load(object sender, EventArgs e)
        {

        }

        private void Email_TextChanged(object sender, EventArgs e)
        {
            Senha.PasswordChar = '*';
        }

        private void Pseguranca_TextChanged(object sender, EventArgs e)
        {
            Pseguranca.PasswordChar = '*';
        }
    }
}
