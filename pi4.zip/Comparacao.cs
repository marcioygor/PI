﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BancoD;
using b;

namespace $safeprojectname$
{
    public partial class Comparacao : Form
    {
        public Comparacao(string nome_produto, string categoria_produto2, string categoria_produto1)
        {


            //posicionando o form no centro da tela 

            //posicionando o form no centro da tela 
            this.StartPosition = FormStartPosition.CenterScreen;

            InitializeComponent();


            //RECONHENDO DADOS DO PRIMEIRO PRODUTO

            BdControl novo = new BdControl();
            ArrayList dados = new ArrayList();

            int id_categoria = novo.RetornaId(categoria_produto1);
            int id_produto = novo.RetornaIdProduto(nome_produto, id_categoria);
            dados = novo.RetornaDadosProd(nome_produto, id_produto);

            lb1.Text = dados[0].ToString();
            lb2.Text = dados[1].ToString();
            lb3.Text = dados[2].ToString();
            lb4.Text = dados[3].ToString();
            lb5.Text = dados[4].ToString();


            //RECONHENDO DADOS DO SEGUNDO PRODUTO

            ArrayList dados2 = new ArrayList();

            int id_categoria2 = novo.RetornaId(categoria_produto2);
            int id_produto2 = novo.RetornaIdProduto(nome_produto, id_categoria2);
            dados2 = novo.RetornaDadosProd(nome_produto, id_produto2);

            lb6.Text = dados2[0].ToString();
            lb7.Text = dados2[1].ToString();
            lb8.Text = dados2[2].ToString();
            lb9.Text = dados2[3].ToString();
            lb10.Text = dados2[4].ToString();


        }

        private void Comparacao_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();

        }
    }
}