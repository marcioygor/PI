﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;
using BancoD;
using b;

namespace $safeprojectname$
{
    public partial class ExibiFav : Form
    {

        string nome_categ;
        int id_categ = 0;

        public ExibiFav(string nome, string nome_categoria)
        {

            //posicionando o form no centro da tela 

            //posicionando o form no centro da tela 
            this.StartPosition = FormStartPosition.CenterScreen;



            InitializeComponent();

            nome_categ = nome_categoria;


            int id_user = 0;
            ArrayList Nomes = new ArrayList();
            BdControl bd = new BdControl();
            //Produto fav = new Produto();
            id_user = bd.RetornaIdUsuario(nome);
            id_categ = bd.RetornaId(nome_categoria);

           Nomes = bd.RetornaFav(id_user, id_categ);

            if (Nomes[0] == "erro")
            {

                this.Close();
            }
           
            

            cb1.DataSource = Nomes;
            
            
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            nome_categ = cb1.SelectedItem.ToString();
    
            BdControl dados = new BdControl();
          
            ArrayList s = new ArrayList();

            s = dados.RetornaDadosProd(nome_categ, id_categ);

            lb1.Text = s[0].ToString();
            lb2.Text = s[1].ToString();
            lb3.Text = s[2].ToString();
            lb4.Text = s[3].ToString();
            lb5.Text = s[4].ToString();
        }

        private void ExibiFav_Load(object sender, EventArgs e)
        {

        }
    }
}
