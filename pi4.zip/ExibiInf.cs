﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BancoD;
using ClasseP;
using b; //usando a blibioteca onde estar o control


namespace $safeprojectname$
{
    public partial class ExibiInf : Form
    {

        ArrayList s = new ArrayList();
        int id_usuario;

        public ExibiInf()
        {
            InitializeComponent();
        }


        public ExibiInf(int id, string Produto, string nome)
        {
            ArrayList s = new ArrayList();

            //posicionando o form no centro da tela 
            this.StartPosition = FormStartPosition.CenterScreen;

            InitializeComponent();
           

            BdControl retorne = new BdControl();

            s = retorne.RetornaDadosProd(Produto, id);

            l1.Text = s[0].ToString();
            l2.Text = s[1].ToString();
            l3.Text = s[2].ToString();
            l4.Text = s[3].ToString();
            l5.Text = s[4].ToString();
            l6.Text = s[5].ToString();


            //pegando o id do usuario
            id_usuario = retorne.RetornaIdUsuario(nome);


        }


        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            BdControl novo = new BdControl();
            int id_produto = 0; 
            int id_categoria = 0;
           
            //métodos da classe bdconexao

            id_categoria = novo.RetornaId(l6.Text); //pegando o id da categoria
            id_produto =novo.RetornaIdProduto(l1.Text,id_categoria); //pegando o id do produto


            //métodos da casse produto
            ProdutoControl fav = new ProdutoControl();
            fav.SalvarFavorito(l1.Text, l2.Text, l3.Text, l5.Text, l4.Text, id_produto, id_usuario, id_categoria); //inserindo no banco

        }

    private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void la_Click(object sender, EventArgs e)
        {
            
        }

        private void ExibiInf_Load(object sender, EventArgs e)
        {

        }

        private void l5_Click(object sender, EventArgs e)
        {

        }

        private void Comparar_Click(object sender, EventArgs e)
        {
            TCompare novaform = new TCompare(l1.Text, l6.Text);
            novaform.Show();
           
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void l6_Click(object sender, EventArgs e)
        {

        }
    }
}
