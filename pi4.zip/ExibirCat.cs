﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Collections;

namespace $safeprojectname$
{
    public partial class ExibirCat : Form
    {

        string categ = "";
        string nome_user;
        

        public ExibirCat(string nome)
        {

            //posicionando o form no centro da tela 

            //posicionando o form no centro da tela 
            this.StartPosition = FormStartPosition.CenterScreen;

            InitializeComponent();

            //Preenchendo valores do combobox

            cb1.Items.Add("Plastico");
            cb1.Items.Add("Metal");
            cb1.Items.Add("Vidro");

            nome_user = nome; //pegando o nickname do usuario


        }

        private void cb1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void ExibirCat_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            categ = cb1.SelectedItem.ToString(); //pegando o que foi selecionado na categoria


            try {
                ExibiFav novo = new ExibiFav(nome_user, categ); //irá abrir a janela favoritos se ele tiver um favorito dessa categoria
                novo.Show();
            }

            catch
            {

                MessageBox.Show("Você não tem favorito que pertence a essa categoria!");
            }

            
        }
    }
}
