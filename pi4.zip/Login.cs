﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Odbc;
using System.Data.SqlClient;
using BancoD;
using b;

namespace $safeprojectname$
{
    public partial class Login : Form

    {
        public string a;
        public int id;

        public Login()
        {

            //posicionando o form no centro da tela 

           // this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
           // this.ClientSize = new System.Drawing.Size(292, 273);

            this.StartPosition = FormStartPosition.CenterScreen; 

            InitializeComponent();
            Senha.PasswordChar = '*';
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {


            BdControl novo = new BdControl();
            bool result = false;
            string a = "";



            try
            {
                OdbcCommand cmd = new OdbcCommand("select nickname, id_usuario from usuario where Nickname = '" + Nick.Text + "' and senha = '" + Senha.Text + "';", novo.cn1);
                novo.Conectar();
                OdbcDataReader dados = cmd.ExecuteReader();
                result = dados.HasRows;

                a = dados["Nickname"].ToString();

            }


            catch (Exception e1)
            {

                
                MessageBox.Show("Nickame ou senha incorretos!");
                Nick.Text = "";  //limpando os campos nickname e senha
                Senha.Text = "";
            }

            if (result)
            {
                
                TPrincipal novaform = new TPrincipal(a);
                Nick.Text = "";  //limpando os campos nickname e senha
                Senha.Text = "";
                novaform.Show();


            }

           



        }

    






        private void button2_Click(object sender, EventArgs e)
        {
            Cadastro novaform = new Cadastro();
            novaform.Show();
        }

        private void Senha_TextChanged(object sender, EventArgs e)
        {

        }

        private void Login_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

            AlterarSenha novo = new AlterarSenha();
            novo.Show();


        }
    }
}
