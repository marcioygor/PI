﻿namespace $safeprojectname$
{
    partial class TCompare
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cb1 = new System.Windows.Forms.ComboBox();
            this.l1 = new System.Windows.Forms.Label();
            this.Comparar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // cb1
            // 
            this.cb1.FormattingEnabled = true;
            this.cb1.Location = new System.Drawing.Point(12, 55);
            this.cb1.Name = "cb1";
            this.cb1.Size = new System.Drawing.Size(121, 21);
            this.cb1.TabIndex = 1;
            this.cb1.SelectedIndexChanged += new System.EventHandler(this.cb1_SelectedIndexChanged);
            // 
            // l1
            // 
            this.l1.AutoSize = true;
            this.l1.Location = new System.Drawing.Point(12, 23);
            this.l1.Name = "l1";
            this.l1.Size = new System.Drawing.Size(105, 13);
            this.l1.TabIndex = 4;
            this.l1.Text = "Escolha a Categoria:";
            // 
            // Comparar
            // 
            this.Comparar.Location = new System.Drawing.Point(93, 226);
            this.Comparar.Name = "Comparar";
            this.Comparar.Size = new System.Drawing.Size(75, 23);
            this.Comparar.TabIndex = 5;
            this.Comparar.Text = "Comparar";
            this.Comparar.UseVisualStyleBackColor = true;
            this.Comparar.Click += new System.EventHandler(this.Comparar_Click);
            // 
            // TCompare
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(332, 261);
            this.Controls.Add(this.Comparar);
            this.Controls.Add(this.l1);
            this.Controls.Add(this.cb1);
            this.Name = "TCompare";
            this.Text = "TCompare";
            this.Load += new System.EventHandler(this.TCompare_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cb1;
        private System.Windows.Forms.Label l1;
        private System.Windows.Forms.Button Comparar;
    }
}