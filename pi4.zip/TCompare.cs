﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BancoD;
using b;

namespace $safeprojectname$
{
    public partial class TCompare : Form
    {

        string produto1;
        string produto2;
        string categ1;


        public TCompare(string nome, string categoria)
        {

            //posicionando o form no centro da tela 
            this.StartPosition = FormStartPosition.CenterScreen;

            InitializeComponent();

            produto1 = nome;
            categ1 = categoria;

            BdControl novo = new BdControl();
            ArrayList nomes = new ArrayList();
            nomes=novo.CompareProduto(nome, categoria);
            cb1.DataSource = nomes;
            cb1.DisplayMember = "Produtos";

        }

        private void Comparar_Click(object sender, EventArgs e)
        {
            //pegando o que foi selecionado no combobox

            produto2 = cb1.SelectedItem.ToString();

            Comparacao novaform = new Comparacao(produto1, produto2, categ1); 
             novaform.Show();
        }

        private void TCompare_Load(object sender, EventArgs e)
        {

        }

        private void cb1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
