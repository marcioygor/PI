﻿namespace $safeprojectname$
{
    partial class TPrincipal
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb1 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.Categ = new System.Windows.Forms.ComboBox();
            this.Produt = new System.Windows.Forms.ComboBox();
            this.button2 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Exibir = new System.Windows.Forms.ToolStripMenuItem();
            this.MeusFav = new System.Windows.Forms.ToolStripMenuItem();
            this.plasticoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.meToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vidroToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.exibirToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.meusFavoritosToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.plasticoToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.metalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.vidroToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.exibirToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.meusFavoritosToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.plasticoToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.metalToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.vidroToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.button3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lb1
            // 
            this.lb1.AutoSize = true;
            this.lb1.Location = new System.Drawing.Point(219, 32);
            this.lb1.Name = "lb1";
            this.lb1.Size = new System.Drawing.Size(82, 13);
            this.lb1.TabIndex = 0;
            this.lb1.Text = "Seja Bem Vindo";
            this.lb1.Click += new System.EventHandler(this.label1_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(573, 22);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Fazer Logoff";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Categ
            // 
            this.Categ.FormattingEnabled = true;
            this.Categ.Location = new System.Drawing.Point(39, 121);
            this.Categ.Name = "Categ";
            this.Categ.Size = new System.Drawing.Size(121, 21);
            this.Categ.TabIndex = 2;
            this.Categ.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Produt
            // 
            this.Produt.FormattingEnabled = true;
            this.Produt.Location = new System.Drawing.Point(351, 121);
            this.Produt.Name = "Produt";
            this.Produt.Size = new System.Drawing.Size(121, 21);
            this.Produt.TabIndex = 3;
            this.Produt.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(135, 326);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(110, 23);
            this.button2.TabIndex = 5;
            this.button2.Text = "Exibir Informações ";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(36, 93);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(80, 13);
            this.label1.TabIndex = 6;
            this.label1.Text = "Lista Categoria:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(348, 93);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 7;
            this.label2.Text = "Lista Produto:";
            // 
            // Exibir
            // 
            this.Exibir.Name = "Exibir";
            this.Exibir.Size = new System.Drawing.Size(47, 20);
            this.Exibir.Text = "Exibir";
            this.Exibir.Click += new System.EventHandler(this.exibirFavoritosToolStripMenuItem_Click);
            // 
            // MeusFav
            // 
            this.MeusFav.Name = "MeusFav";
            this.MeusFav.Size = new System.Drawing.Size(154, 22);
            this.MeusFav.Text = "Meus Favoritos";
            this.MeusFav.Click += new System.EventHandler(this.meusFavoritosToolStripMenuItem_Click_1);
            // 
            // plasticoToolStripMenuItem
            // 
            this.plasticoToolStripMenuItem.Name = "plasticoToolStripMenuItem";
            this.plasticoToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.plasticoToolStripMenuItem.Text = "Plastico";
            this.plasticoToolStripMenuItem.Click += new System.EventHandler(this.plasticoToolStripMenuItem_Click);
            // 
            // meToolStripMenuItem
            // 
            this.meToolStripMenuItem.Name = "meToolStripMenuItem";
            this.meToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.meToolStripMenuItem.Text = "Metal";
            this.meToolStripMenuItem.Click += new System.EventHandler(this.meToolStripMenuItem_Click);
            // 
            // vidroToolStripMenuItem
            // 
            this.vidroToolStripMenuItem.Name = "vidroToolStripMenuItem";
            this.vidroToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.vidroToolStripMenuItem.Text = "Vidro";
            this.vidroToolStripMenuItem.Click += new System.EventHandler(this.vidroToolStripMenuItem_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(695, 24);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            this.menuStrip1.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.menuStrip1_ItemClicked_1);
            // 
            // exibirToolStripMenuItem
            // 
            this.exibirToolStripMenuItem.Name = "exibirToolStripMenuItem";
            this.exibirToolStripMenuItem.Size = new System.Drawing.Size(47, 20);
            this.exibirToolStripMenuItem.Text = "Exibir";
            // 
            // meusFavoritosToolStripMenuItem
            // 
            this.meusFavoritosToolStripMenuItem.Name = "meusFavoritosToolStripMenuItem";
            this.meusFavoritosToolStripMenuItem.Size = new System.Drawing.Size(154, 22);
            this.meusFavoritosToolStripMenuItem.Text = "Meus Favoritos";
            // 
            // plasticoToolStripMenuItem1
            // 
            this.plasticoToolStripMenuItem1.Name = "plasticoToolStripMenuItem1";
            this.plasticoToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.plasticoToolStripMenuItem1.Text = "Plastico";
            this.plasticoToolStripMenuItem1.Click += new System.EventHandler(this.plasticoToolStripMenuItem1_Click);
            // 
            // metalToolStripMenuItem
            // 
            this.metalToolStripMenuItem.Name = "metalToolStripMenuItem";
            this.metalToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.metalToolStripMenuItem.Text = "Metal";
            // 
            // vidroToolStripMenuItem1
            // 
            this.vidroToolStripMenuItem1.Name = "vidroToolStripMenuItem1";
            this.vidroToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.vidroToolStripMenuItem1.Text = "Vidro";
            // 
            // exibirToolStripMenuItem1
            // 
            this.exibirToolStripMenuItem1.Name = "exibirToolStripMenuItem1";
            this.exibirToolStripMenuItem1.Size = new System.Drawing.Size(47, 20);
            this.exibirToolStripMenuItem1.Text = "Exibir";
            // 
            // meusFavoritosToolStripMenuItem1
            // 
            this.meusFavoritosToolStripMenuItem1.Name = "meusFavoritosToolStripMenuItem1";
            this.meusFavoritosToolStripMenuItem1.Size = new System.Drawing.Size(154, 22);
            this.meusFavoritosToolStripMenuItem1.Text = "Meus Favoritos";
            // 
            // plasticoToolStripMenuItem2
            // 
            this.plasticoToolStripMenuItem2.Name = "plasticoToolStripMenuItem2";
            this.plasticoToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.plasticoToolStripMenuItem2.Text = "Plastico";
            this.plasticoToolStripMenuItem2.Click += new System.EventHandler(this.plasticoToolStripMenuItem2_Click);
            // 
            // metalToolStripMenuItem1
            // 
            this.metalToolStripMenuItem1.Name = "metalToolStripMenuItem1";
            this.metalToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.metalToolStripMenuItem1.Text = "Metal";
            // 
            // vidroToolStripMenuItem2
            // 
            this.vidroToolStripMenuItem2.Name = "vidroToolStripMenuItem2";
            this.vidroToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.vidroToolStripMenuItem2.Text = "Vidro";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(335, 326);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(128, 23);
            this.button3.TabIndex = 10;
            this.button3.Text = "Exibir Meus Favoritos";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click_1);
            // 
            // TPrincipal
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(695, 361);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.Produt);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Categ);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lb1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "TPrincipal";
            this.Text = "TPrincipal";
            this.Load += new System.EventHandler(this.TPrincipal_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.ComboBox Categ;
        private System.Windows.Forms.ComboBox Produt;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ToolStripMenuItem Exibir;
        private System.Windows.Forms.ToolStripMenuItem MeusFav;
        private System.Windows.Forms.ToolStripMenuItem plasticoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem meToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vidroToolStripMenuItem;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem exibirToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem meusFavoritosToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem plasticoToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem metalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem vidroToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem exibirToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem meusFavoritosToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem plasticoToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem metalToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem vidroToolStripMenuItem2;
        private System.Windows.Forms.Button button3;
    }
}