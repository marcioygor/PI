﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Odbc;
using System.Collections;
using BancoD;
using b;

namespace $safeprojectname$
{
    public partial class TPrincipal : Form
    {

          string categoria;
          string Produto;
          int id_Categ = 0;
          string nome_user = "";

        ArrayList Dados = new ArrayList();

        public TPrincipal(string nome)
        {
            this.StartPosition = FormStartPosition.CenterScreen;

            InitializeComponent();

            ArrayList Nomes1 = new ArrayList();

            lb1.Text = "Seja bem vindo, " + nome;


             Categ.Items.Add("Plastico");
             Categ.Items.Add("Metal");
             Categ.Items.Add("Vidro");
             nome_user = nome;
          




        }

        private void label1_Click(object sender, EventArgs e)
        {
          
            
        }

        private void teste1_TextChanged(object sender, EventArgs e)
        {
            

           
        }

        private void button1_Click(object sender, EventArgs e)
        {

            //Login a = new Login();
            
            MessageBox.Show("Até mais, " + nome_user);
            this.Close(); //fechando todas as janelas
            Login novo = new Login(); //abrindo a janela de login
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            //pegando o que foi selecionado na primeira categoria 

            categoria = Categ.SelectedItem.ToString();

            //jogando dados no segundo combobox 

            int id = 0;
            ArrayList Nomes = new ArrayList();



            BdControl bd = new BdControl();
            id = bd.RetornaId(categoria);
            Nomes = bd.RetornaNome(id);


            Produt.DataSource = Nomes;
            Produt.DisplayMember = "Produtos";


            id_Categ = bd.RetornaId(categoria);

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {

            


              

        }


        private void button2_Click(object sender, EventArgs e)
        {

            //pegando o que foi selecionado no segundo combobox 

            Produto = Produt.SelectedItem.ToString();

            
            //abrindo a janela para exibir as informaçõs do produto passando como parametro o id da categoria, o nome do produto e o nickname do usuario
            ExibiInf novaform = new ExibiInf(id_Categ, Produto, nome_user);
            novaform.Show();

           
        }

        private void button3_Click(object sender, EventArgs e)
        {

             

        }




            public ArrayList RetornarNome()
        {

               return Dados;



        }

        private void TPrincipal_Load(object sender, EventArgs e)
        {

        }

        private void favoritosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void contextMenuStrip1_Opening(object sender, CancelEventArgs e)
        {
           
        }

        private void exibToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void toolStripComboBox1_Click(object sender, EventArgs e)
        {
           // Fav.Style = csDropDownList;
        }

        private void favoritosToolStripMenuItem_Click_1(object sender, EventArgs e)
        {

        }

        private void toolStripComboBox1_Click_1(object sender, EventArgs e)
        {
          
            

            // Abre a ComboBox (se já não estiver aberta)

          //  if (!this.Fav.DroppedDown)

          //  {
               // this.Fav.DroppedDown = true;

          //  }

        }

        private void toolStripComboBox1_Click_2(object sender, EventArgs e)
        {
               

        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

             
        }

        private void meusFavoritosToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void favoritosToolStripMenuItem_Click_2(object sender, EventArgs e)
        {
          


        }

        private void exibirFavoritosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

        }

        private void favoritosToolStripMenuItem_Click_3(object sender, EventArgs e)
        {
            
        

        }

        private void toolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void toolStripComboBox1_Click_3(object sender, EventArgs e)
        {
          



        }

        private void comboBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            

        }

        private void meusFavoritosToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
           
        }

        private void plasticoToolStripMenuItem_Click(object sender, EventArgs e)
        {

            MessageBox.Show(plasticoToolStripMenuItem.ToString());


            try {
                ExibiFav novaform = new ExibiFav(nome_user, plasticoToolStripMenuItem.ToString());
                novaform.Show();

            } 

            catch(Exception e3)
            {

                MessageBox.Show("Você não tem favorito que pertence a essa categoria");
            }
           
        }

        private void meToolStripMenuItem_Click(object sender, EventArgs e)
        {
            

        }

        private void vidroToolStripMenuItem_Click(object sender, EventArgs e)
        {

           


        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void plasticoToolStripMenuItem1_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked_1(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void plasticoToolStripMenuItem2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            ExibirCat novo = new ExibirCat(nome_user);
            novo.Show();
        }
    }
    }
    

