CREATE TABLE USUARIO(

  ID_USUARIO NUMBER NOT NULL ENABLE,
  NOME VARCHAR2(60),
  NICKNAME VARCHAR2(60),
  SENHA VARCHAR2(60),
  PALAVRA_SEG VARCHAR2(60),
  CONSTRAINT USUARIO_PK PRIMARY KEY (ID_USUARIO) ENABLE
) ;
 
 
 
CREATE TABLE PRODUTO(

  ID_PRODUTO NUMBER NOT NULL ENABLE,
  NOME VARCHAR2(60),
  DESCRICAO VARCHAR2(200),
  COMPOSICAO VARCHAR2(60),
  IMPACTO VARCHAR2(200),
  TEMPO_DECOMP VARCHAR2(30),
  ID_CATEGORIA NUMBER NULL,
  ID_ESCOLHA NUMBER NULL,
  NOME_CATEGORIA VARCHAR(60) NULL,
  CONSTRAINT PRODUTO_PK PRIMARY KEY (ID_PRODUTO) ENABLE
) ;   



CREATE TABLE CATEGORIA

  ID_CATEGORIA NUMBER NOT NULL ENABLE,
  NOME VARCHAR2(60),
  DESCRICAO VARCHAR2(120),
  CONSTRAINT CATEGORIA_PK PRIMARY KEY (ID_CATEGORIA) ENABLE
) ; 


CREATE TABLE FAVORITOS

  ID_FAVORITOS NUMBER NOT NULL ENABLE,
  NOME VARCHAR2(60),
  DESCRICAO VARCHAR2(200),
  COMPOSICAO VARCHAR2(60),
  IMPACTO VARCHAR2(200),
  TEMPO_DECOMP VARCHAR2(30),
  ID_USUARIO NUMBER NULL,
  CONSTRAINT FAVORITOS_PK PRIMARY KEY (ID_FAVORITOS) ENABLE
) ; 



/* triggers*/
create or replace trigger increment_fav_id2
        before insert on favoritos 
        for each row
    begin
        if :new.id_favoritos is null then
            SELECT id_user.nextval into :new.id_favoritos from dual;
        end if;
    end;  
    
  
  create or replace trigger increment_user_id
        before insert on usuario
        for each row
    begin
        if :new.id_usuario is null then
            SELECT id_usuario.nextval into :new.id_usuario from dual;
        end if;
    end;  
    
      create or replace trigger increment_Produto_id
        before insert on Produto
        for each row
    begin
        if :new.id_Produto is null then
            SELECT id_Produto.nextval into :new.id_produto from dual;
        end if;
    end; 
  

  
/*sequencia*/ 
create sequence id_usuario
minvalue 1
maxvalue 9999999999
start with 12
increment by 1
nocache
cycle;  

create sequence id_Produto
minvalue 1
maxvalue 9999999999
start with 12
increment by 1
nocache
cycle;  



select * from produto;

/*Consultas Simples */

select u.nome, e.data_escolha from usuario u
join escolha e on u.id_usuario=e.id_usuario;

select c.nome, p.nome, f.nome from categoria c join produto p
on c.id_categoria=p.id_produto join favoritos f on
p.id_produto=f.id_produto;


select u.nome, e.data_escolha, p.descricao from usuario u join
escolha e on u.id_usuario=e.id_usuario join produto p
on e.id_categoria=p.id_categoria; 


select c.descricao, p.nome, f.nome from categoria c
join produto p on c.id_categoria=p.id_categoria join
favoritos f on p.id_produto=f.id_produto; 


/*Consultas Complexas */ 

select c.nome, p.nome, f.nome from categoria c join produto p
on c.id_categoria=p.id_produto join favoritos f on
p.id_produto=f.id_produto order by c.nome asc; 


select to_char(sysdate) as Data, c.data_escolha, p.descricao, u.id_usuario from
usuario u join escolha c on u.id_usuario=c.id_usuario join produto p
on c.id_categoria=p.id_categoria;

select u.nome, c.nome, p.composicao, u.id_usuario count(u.id_usuario) from
usuario u join categoria c on u.id_usuario=c.id_usuario join
produto p on c.id_categoria=p.id_categoria group by u.id_usuario; 


select u.nome, c.data_escolha, p.descricao, count(u.nome) from usuario u join
escolha c on u.id_usuario=c.id_usuario join produto p
on c.id_categoria=p.id_categoria group by u.nome, c.data_escolha, p.DESCRICAO; 

select u.nome, c.data_escolha, p.tempo_decomp from usuario u
join escolha c on u.id_usuario=c.id_usuario join
produto p on c.id_categoria=p.id_categoria order by u.nome;



/* SubConsultas */ 

select nome from usuario where nome=(select nome from usuario where
id_usuario=1); 

select id_produto from produto where id_produto in (select id_produto from
categoria where nome<>'vidro');  

select id_produto from produto where id_produto in(select id_produto from favoritos
where nome <>'plastico'); 


/* left join e rigth join */

select u.nome, c.produto_1 , c.data_escolha from usuario u left join escolha c
on u.id_usuario = c.id_usuario; 

select p.nome, f.nome  from produto p left join favoritos f on p.id_produto=
f.id_produto;



/* Procedure */ 


CREATE PROCEDURE remove_prod (id_Produto NUMBER) AS� total_prod
NUMBER;
� BEGIN
� � DELETE FROM Produto
� � WHERE Produto.id_Produto = remove_prod.id_Produto;
� total_prod := total_prod - 1;
� END;


CREATE OR REPLACE PROCEDURE add_category (
  c_nome IN categoria.nome%TYPE,
  c_descricao IN categoria.descricao%TYPE) IS
  BEGIN
      INSERT INTO categoria (id_categoria, nome, descricao)
      VALUES (categoria_seq.NEXTVAL, c_nome, c_descricao);
END add_category;
EXECUTE add_category (c_nome => �Papel�, c_descricao => �Celulose�);

/* Function */ 


CREATE OR REPLACE FUNCTION quant_usuarios
(u_id usuario.id_Usuario %TYPE) RETURN NUMBER IS
BEGIN
SELECT COUNT (*) AS total_usuarios FROM usuario WHERE
id_Usuario = u_id;
RETURN total_usuarios
dbms_output.put_line ('O Total de usu�rios nessa tabela �:' ||
total_usuarios);
END quant_usuarios;  



CREATE OR REPLACE FUNCTION Nome_Nickname (userid NUMBER)
� RETURN VARCHAR2 IS
� firstname� usuario.nome%TYPE;
� apelido usuario.nickname%TYPE;
BEGIN
� SELECT nome, nickname INTO firstname, apelido FROM usuario�
��� WHERE id_usuario = userid;
� RETURN ('Usu�rio: '||'-' userid ||  - || INITCAP(fisrtname)�
�������������������������������� || ','|| UPPER(apelido));
END Nome_Nickname;